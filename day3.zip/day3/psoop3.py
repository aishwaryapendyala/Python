"""
PackageManager

name
version

__init__()
get_information()
"""


class PackageManager:
    def __init__(self, name, version, arch):
        self.__name = name
        self.version = version
        self.arch = arch

    def __get_information(self):
        print('name :', self.__name)
        print('version :', self.version)
        print(self.arch)

    def wrapper(self):
        self.__get_information()


pm = PackageManager('pip', '2.2.18', 'x86_64')
pm.wrapper()
# print(pm.__name)
