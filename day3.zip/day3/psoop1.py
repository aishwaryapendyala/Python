import math
import os
import sys


class Demo:
    pass


d = Demo()
print(d)
print(Demo)
print(__name__)  # get the default namespace
print(sys.__name__)
print(math.__name__)
print(os.__name__)
