"""
scope
    -global
    -local  (function)
"""

n = 123 # global


def demo():
    n = 'pypi'  # local to the functions
    print(n)


demo()
print(n)

