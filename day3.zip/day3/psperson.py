class Person:
    def __init__(self, fn, ln):
        self.first_name = fn
        self.last_name = ln

    def get_info(self):
        print('first name :', self.first_name)
        print('last name :', self.last_name)


if __name__ == '__main__':
    p = Person('larry', 'wall')
    p.get_info()
    print(__name__)
