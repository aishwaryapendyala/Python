import pyexcel
from csv import reader


class CSV2XLSX:
    def __init__(self, csv_file, xlsx_file):
        self.csv = csv_file
        self.xlsx = xlsx_file
        self.__dump()

    def __dump(self):
        list_of_records = [row for row in reader(open(self.csv), delimiter=':')]
        pyexcel.save_as(array=list_of_records, dest_file_name=self.xlsx)


def read_xlsx(xlsx_file):
    sheet = pyexcel.get_sheet(file_name=xlsx_file)
    for row in sheet:
        print(row)

if __name__ == '__main__':
    # CSV2XLSX('passwd.txt.bak', 'passwd.xlsx')
    read_xlsx('passwd.xlsx')