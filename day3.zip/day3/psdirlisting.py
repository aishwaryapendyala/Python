from os import listdir
from os.path import isfile, join, getsize, getmtime, basename
from time import ctime
from pprint import pprint as pp


class DirectoryListing:
    def __init__(self, *args):
        self.directories = args
        self.container = dict()
        self.__read_directories()

    def __read_directories(self):
        for dir_name in self.directories:
            dir_items = [join(dir_name, item) for item in listdir(dir_name)]
            file_names = filter(isfile, dir_items)
            temp = dict()

            for file_name in file_names:
                file_prop = [getsize(file_name), ctime(getmtime(file_name))]
                file_name = basename(file_name)
                temp[file_name] = file_prop

            self.container[dir_name] = temp


if __name__ == '__main__':
    dl = DirectoryListing('/tmp', '/home/ravi')
    pp(dl.container)

"""
{
d1: {
    f1: [size, mtime],
    f2 : [size, mtime],....
    }, 
    
d2: {
    g1: [size, mtime],...
    }, .....
}
 
"""
