import fileinput

print(dir(fileinput))

def copy_all(*args):

    with open(args[-1], 'w') as fw:  # context manager
        for file_name in args[:-1]:
            fw.write(file_name.center(60, '-') + "\n")

            content = open(file_name).read()

            if not content.endswith('\n'):
                content += "\n"

            fw.write(content)
            fw.write('-' * 60 + "\n")


copy_all('/etc/hosts', '/etc/resolv.conf', 'testit')
