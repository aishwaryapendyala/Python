from os import listdir
from os.path import join, isfile, isdir, getsize, getmtime
from time import ctime


dir_name = r'windows-path'
dir_name = '/tmp'  # unix

print(listdir(dir_name))
print()

# abs_path = dir_name +'/'+ 'lu284742j066j.tmp'
abs_path = join(dir_name, 'lu284742j066j.tmp')
print(abs_path)
print(isfile(abs_path))
print(isdir(abs_path))
print()
print(getsize(abs_path))
print(getmtime(abs_path))
print(ctime(getmtime(abs_path)))