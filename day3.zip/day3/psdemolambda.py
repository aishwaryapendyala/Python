# functional programming

# lambda help you to create callable object, anon functions

# syntax:-
# lambda arg1, arg2,..... : expression
def demo():
    print('a dummy call')


power = lambda x, n: x ** n
print(power)
print(power(3, 4))
#print(demo)
#demo()
