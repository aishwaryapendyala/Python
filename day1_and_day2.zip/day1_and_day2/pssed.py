import re
from fileinput import input, filelineno
# from sys import stdout
# inplace edit

pattern = ':'
replacement = ','
filename = 'passwd.txt'

for line in input(filename, inplace=True, backup='.bak'):
    if filelineno() <= 10:
        line = re.sub(pattern, replacement, line)

    print(line, end='')
    # print(line, end='', file=stdout)
