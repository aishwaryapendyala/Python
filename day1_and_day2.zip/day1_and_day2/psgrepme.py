import re
from fileinput import input, filename, filelineno


def grep_me(pattern, list_of_file_names):
    for line in input(list_of_file_names):
        if re.search(pattern, line, re.I):
            print("{}:{}:{}".format(filename(), filelineno(), line), end='')

# grep_me('bash$', 'passwd.txt')
pattern = '([5-9]\d\d)|([1-9]\d{3,})'
grep_me(pattern, 'passwd.txt')
