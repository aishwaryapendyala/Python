def get_users_list(data_file, target_file):
    """
    an abstract about the function
    :param data_file: str
    :param target_file: str
    :return: None
    """
    try:
        list_of_users = list()

        for line in open(data_file):
            login = line.split(':')[0]
            list_of_users.append(login)

        list_of_users.sort()

        fw = open(target_file, 'w')

        for line_no, user in enumerate(list_of_users, 1):
            content = '{:>6}  {}'.format(line_no, user)
            print(content)
            fw.write(content + "\n")

    except (FileNotFoundError, IOError) as err:
        print(err)
    finally:
        fw.close()


get_users_list('passwd.txt', 'passwd.dat')
