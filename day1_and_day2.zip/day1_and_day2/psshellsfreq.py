from pprint import pprint as pp
from csv import reader


def group_users_by_shell(data_file):
    group_by = dict()

    for record in reader(open(data_file), delimiter=':'):
        login, shell = record[0], record[6]

        if shell not in group_by:
            group_by[shell] = list()

        group_by[shell].append(login)

    return group_by


def get_shells_frequency(data_file):
    shells_count = dict()

    for record in reader(open(data_file), delimiter=':'):
        shell = record[6]
        shells_count[shell] = shells_count.get(shell, 0) + 1

    return shells_count


freq = get_shells_frequency('passwd.txt')
grp_by = group_users_by_shell('passwd.txt')

pp(grp_by)

"""for shell, frequency in freq.items():
    print(shell, ":", frequency)
"""
