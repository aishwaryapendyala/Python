"""a demo for the IO, doc string """

try:
    name = input('enter the name :')
    city = input('enter teh city :')
    zip_code = int(input('enter the zip code :'))

    print('name :', name)
    print('city :', city)
    print(zip_code)
    print(type(zip_code))
except ValueError as err:
    print(err)

# print('the next line of code after the try except block')

# string formatted
