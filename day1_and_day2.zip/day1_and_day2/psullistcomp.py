from pprint import pprint as pp

data = [line.split(':')[0] for line in open('passwd.txt')]

data = [line.split(':')[0] for line in open('passwd.txt') if line.startswith('a')]
pp(sorted(data))