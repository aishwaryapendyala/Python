while -12.21:
    print('@')
