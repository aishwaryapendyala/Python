from pprint import pprint as pp

fp = open('passwd.txt')
print(fp)
#for line in fp:
#    print(line, end='')

#fp.seek(0, 0)
#pp(fp.readlines())
fp.close()