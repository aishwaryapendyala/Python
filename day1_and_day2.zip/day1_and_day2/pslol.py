from pprint import pprint as pp

content = sorted([line.rstrip().split(':') for line in open('passwd.txt')])

captions = ['login', 'passwd', 'uid', 'gid', 'gecos', 'home', 'shell']

for header in captions:
    print(header, end="\t")
print()

for user_values in content:
    for value in user_values:
        print(value, end='\t')
    print()

"""for user_values in content:pslol.py:10
    for title, value in zip(captions, user_values):  # parallel iterations
        print("{:>12} : {}".format(title, value))
    print()
"""