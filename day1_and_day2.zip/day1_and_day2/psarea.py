from math import pi


def compute(radius):   # function definition
    computed_area = pi * (radius ** 2)
    computed_perimeter = 2 * pi * radius
    return computed_area, computed_perimeter


try:
    user_radius = float(input('enter the radius :'))
    # user_radius = float('{:.2f}'.format(user_radius))
    area, perimeter = compute(user_radius)   # calling, parallel assign
    # string formatting  {:fmt-str}
    print('radius = {}\narea = {:.3f}\nperimeter = {}'.format(user_radius,
                                                              area,
                                                              perimeter))
except ValueError as err:
    print(err)
